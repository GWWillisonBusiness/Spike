//
//  Shop.swift
//  Spike
//
//  Created by Grant Willison on 10/7/20.
//

import SwiftUI

struct Shop: View {
    
    // Green = 1, Orange = 2, Yellow = 3,
    @AppStorage ("CharacterValue") var characterValue = 1
    
    //Own The Color of Square (Type) 1 Means No, 2 Means Yes
    @AppStorage ("ownColorGreen") var ownColorGreen = 2
    @AppStorage ("ownColorOrange") var ownColorOrange = 1
    @AppStorage ("ownColorYellow") var ownColorYellow = 1

  
    
    //Free Currency
    @AppStorage ("Coin") var Coin = 101
    
    //Paid Currency
    @AppStorage ("Ruby") var Ruby = 0
    
    var body: some View {
        ZStack{
            Rectangle()
           .foregroundColor(Color(red: 85/255, green: 85/255, blue: 85/255))
           .edgesIgnoringSafeArea(.all)
            
       
            VStack{
                Text("Shop")
                    .bold()
                    .underline()
                    .foregroundColor(Color(red: 0/255, green: 0/255, blue: 0/255))
                    .font(.system(size: 42))
                
                Spacer()
                
                Text("Skins")
                    .bold()
                    .foregroundColor(Color(red: 95/255, green: 250/255, blue: 77/255))
                    .font(.system(size: 20))
                
                HStack{
                    Spacer__()
                    Spacer()
                    
                    ZStack{
                        if ownColorGreen == 2 {
                    Image("SpikeCharacter")
                        .padding(.all, 30)
                        .background(Color.white)
                        .opacity(1.00)
                        .cornerRadius(20)
                        Button("                          "){
                            characterValue = 1
                            }
                        }
                    }
                
                Spacer__()
                    ZStack{
                        if ownColorOrange == 1 {
                    Image("SpikeCharacterOrange")
                        .padding(.all, 30)
                        .background(Color.white)
                        .opacity(0.50)
                        .cornerRadius(20)
                        Button("                          "){
                            if Coin >= 100 {
                                Coin -= 100
                                ownColorOrange = 2
                            }
                        }
                    }
                        if ownColorOrange == 2 {
                    Image("SpikeCharacterOrange")
                        .padding(.all, 30)
                        .background(Color.white)
                        .opacity(1.00)
                        .cornerRadius(20)
                        Button("                          "){
                            characterValue = 2
                                ownColorOrange = 2
                            
                        }
                    }
                        
                        
                        
                }
                    Spacer__()
                    ZStack{
                        if ownColorYellow == 1 {
                    Image("SpikeCharacterYellow")
                        .padding(.all, 30)
                        .background(Color.white)
                        .opacity(0.50)
                        .cornerRadius(20)
                        Button("                          "){
                            if Coin >= 500 {
                                Coin -= 500
                                ownColorYellow = 2
                            }
                        }
                    }
                        if ownColorYellow == 2 {
                    Image("SpikeCharacterYellow")
                        .padding(.all, 30)
                        .background(Color.white)
                        .opacity(1.00)
                        .cornerRadius(20)
                        Button("                          "){
                            characterValue = 3
                                ownColorYellow = 2
                            
                        }
                    }

                            }
                    Spacer__()
                    Spacer()
                    }
               
                HStack{
                    Spacer()
                    Text("Green - Free")
                        .bold()
                    Spacer()
                Text("Orange - 100")
                    .bold()
                    Spacer()
                Text("Yellow - 500")
                    .bold()
                    Spacer()
                }
                HStack{
                    Spacer()
                    if characterValue == 1 {
                    Text("Active")
                        .bold()
                        .foregroundColor(Color.white)
                    }
                    Spacer__()
                    if characterValue == 2 {
                    Text("Active")
                            .bold()
                            .foregroundColor(Color.white)
                    }
                    
                    Spacer__()
                    if characterValue == 3 {
                    Text("Active")
                            .bold()
                            .foregroundColor(Color.white)
                    }
                    Spacer()
                }
                                Text("UPGRADES")
                    .bold()
                    .foregroundColor(Color(red: 95/255, green: 250/255, blue: 77/255))
                    .font(.system(size: 20))
                
                                Spacer__()
                
                ZStack{
                    Text("Reset")
                        .bold()
                    Button("           "){
                        characterValue = 1
                        ownColorGreen = 2
                        ownColorOrange = 1
                        ownColorYellow = 1
                        }
                    }
                }
            }
        }
    }

struct Shop_Previews: PreviewProvider {
    static var previews: some View {
        Shop()
    }
}
