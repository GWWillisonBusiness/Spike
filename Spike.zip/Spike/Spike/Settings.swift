//
//  Settings.swift
//  Spike
//
//  Created by Grant Willison on 10/7/20.
//

import SwiftUI

struct Settings: View {
    
    @State private var HowToPlay: Bool = false
    
    var body: some View {
        
        ZStack{
        Rectangle()
           .foregroundColor(Color(red: 85/255, green: 85/255, blue: 85/255))
           .edgesIgnoringSafeArea(.all)
            
        
            VStack{
                Text("Settings")
                    .bold()
                    .foregroundColor(Color(red: 95/255, green: 250/255, blue: 77/255))
                    .font(.system(size: 42))
                
                Spacer()
                
                ZStack{
                    Text("Audio On/Off")
                        .bold()
                        .foregroundColor(Color(red: 95/255, green: 250/255, blue: 77/255))
                        .padding(.all, 18)
                        .padding([.leading, .trailing], 30)
                        .background(Color(red: 255/255, green: 255/255, blue: 255/255))
                        .cornerRadius(20)

                    Button("                                        "){
                        //Turn Audio On and Off
                        
                    }
                }
                    Spacer()
                    
                    ZStack{
                        Text("Restore Purchases")
                            .bold()
                            .foregroundColor(Color(red: 95/255, green: 250/255, blue: 77/255))
                            .padding(.all, 18)
                            .padding([.leading, .trailing], 30)
                            .background(Color(red: 255/255, green: 255/255, blue: 255/255))
                            .cornerRadius(20)

                        Button("                                        "){
                            //Turn Audio On and Off
                            
                        }
                    }
                        Spacer()
                ZStack{
                Text("How To Play")
                            .bold()
                            .foregroundColor(Color(red: 95/255, green: 250/255, blue: 77/255))
                            .padding(.all, 18)
                            .padding([.leading, .trailing], 30)
                            .background(Color(red: 255/255, green: 255/255, blue: 255/255))
                            .cornerRadius(20)
                        Button("                                                   "){
                            self.HowToPlay = true
                            
                        }
                            
                    
                    Spacer()
                        .sheet(isPresented: $HowToPlay) {
                            ZStack {
                                
                                Rectangle()
                                    .foregroundColor(Color(red: 125/255, green: 125/255, blue: 125/255))
                                    .edgesIgnoringSafeArea(.all)
                                
                                Rectangle()
                                    .foregroundColor(Color(red: 95/255, green: 250/255, blue: 77/255))
                                    .rotationEffect(Angle(degrees: 45))
                                    .edgesIgnoringSafeArea(.all)
                                    

                                Text("The Goal of This Game is Simple. Collect The Blue Circles While Avoiding The Red Squares. Can You Beat The Creator's Score? (208) Good Luck!")
                            }
                }
                }
                Spacer__()
            }
        }
    }
        
    
}
struct Settings_Previews: PreviewProvider {
    static var previews: some View {
        Settings()
    }
}
