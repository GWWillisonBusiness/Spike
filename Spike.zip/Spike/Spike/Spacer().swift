//
//  Spacer().swift
//  Spike
//
//  Created by Grant Willison on 10/7/20.
//

import SwiftUI

struct Spacer__: View {
    var body: some View {
        Spacer()
        Spacer()
    }
}

struct Spacer___Previews: PreviewProvider {
    static var previews: some View {
        Spacer__()
    }
}
