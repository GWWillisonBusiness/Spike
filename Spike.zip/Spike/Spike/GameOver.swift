//
//  GameOver.swift
//  Spike
//
//  Created by Grant Willison on 10/11/20.
//

import SwiftUI

struct GameOver: View {
    
    @AppStorage ("Key To Restart") var Active = 1
    
    var body: some View {
        
       Text("")
    }
}

struct GameOver_Previews: PreviewProvider {
    static var previews: some View {
        GameOver()
    }
}
