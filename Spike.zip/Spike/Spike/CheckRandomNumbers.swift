//
//  CheckRandomNumbers.swift
//  Spike
//
//  Created by Grant Willison on 10/11/20.
//

import SwiftUI

struct CheckRandomNumbers: View {
    
    @State var eRandomX = Int.random(in: 10..<360)
    @State var eRandomY = Int.random(in: 10..<720)
    
    @State var cRandomX = Int.random(in: 10..<361)
    @State var cRandomY = Int.random(in: 10..<721)

    
    var body: some View {
        eRandomX = Int.random(in: 10..<360)
        eRandomY = Int.random(in: 10..<720)

        cRandomX = Int.random(in: 10..<360)
        cRandomY = Int.random(in: 10..<720)
    }
}

struct CheckRandomNumbers_Previews: PreviewProvider {
    static var previews: some View {
        CheckRandomNumbers()
    }
}
