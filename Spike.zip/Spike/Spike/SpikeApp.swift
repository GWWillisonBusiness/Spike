//
//  SpikeApp.swift
//  Spike
//
//  Created by Grant Willison on 10/7/20.
//

import SwiftUI

@main
struct SpikeApp: App {
    var body: some Scene {
        WindowGroup {
            HomeScreen()
        }
    }
}
