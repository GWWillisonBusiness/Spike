//
//  HomeScreen.swift
//  Spike
//
//  Created by Grant Willison on 10/7/20.
//

import SwiftUI

struct HomeScreen: View {
    
    @AppStorage ("Key To Restart") var Active = 1

    
    //Free Currency
    @AppStorage ("Coin") var Coin = 0
    
    //Paid Currency
    @AppStorage ("Ruby") var Ruby = 0
    
    var body: some View {
        
        NavigationView{
            
            ZStack{
                
                Rectangle()
                    .foregroundColor(Color(red: 85/255, green: 85/255, blue: 85/255))
                    .edgesIgnoringSafeArea(.all)
                
                VStack{
                    HStack{
                        
                        Spacer()
                        
                        Text(String(Coin))
                            .bold()
                        Image("CoinLogo")
                            .scaleEffect(0.7)
                        //Add Coin Logo
                        
                        Spacer__()
                        
                        Text(String(Ruby))
                            .bold()
                        Image("RubyLogo")
                            .scaleEffect(0.7)
                        //Add Ruby Logo
                        Spacer()
                        
                    }
                    
                    Spacer()
                    
                    ZStack{
                        Text("Spike")
                            .bold()
                            .foregroundColor(Color(red: 95/255, green: 250/255, blue: 77/255))
                            .font(.system(size: 42))
                        
                    }
                    
                    Spacer__()
                    
                    ZStack{
                        
                        NavigationLink(destination: Play()
                            .navigationTitle(Text(""))
                            .navigationBarHidden(true))
                        {
                            
                            Text("Play")
                                .bold()
                                .foregroundColor(Color(red: 95/255, green: 250/255, blue: 77/255))
                                .padding(.all, 18)
                                .padding([.leading, .trailing], 30)
                                .background(Color(red: 255/255, green: 255/255, blue: 255/255))
                                .cornerRadius(20)
                        }
                    }
                    
                    Spacer()
                    
                    ZStack{
                        NavigationLink(destination: Shop()) {
                            Text("Shop")
                                .bold()
                                .foregroundColor(Color(red: 95/255, green: 250/255, blue: 77/255))
                                .padding(.all, 18)
                                .padding([.leading, .trailing], 30)
                                .background(Color(red: 255/255, green: 255/255, blue: 255/255))
                                .cornerRadius(20)
                            
                            
                        }
                    }
                    
                    Spacer()
                    
                    ZStack{
                        
                        NavigationLink(destination: Settings()) {
                            Text("Settings")
                                .bold()
                                .foregroundColor(Color(red: 95/255, green: 250/255, blue: 77/255))
                                .padding(.all, 18)
                                .padding([.leading, .trailing], 30)
                                .background(Color(red: 255/255, green: 255/255, blue: 255/255))
                                .cornerRadius(20)
                            
                        }
                    }
                    Spacer()
                }
            }
        }
    }
}
struct HomeScreen_Previews: PreviewProvider {
    static var previews: some View {
        HomeScreen()
    }
}
