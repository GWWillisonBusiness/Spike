    //
    //  CharacterMove.swift
    //  Spike
    //
    //  Created by Grant Willison on 10/10/20.
    //
    
    import SwiftUI
    
    
    struct Gameplay: View {
        
        @AppStorage ("eRandomX") var eRandomX = Int.random(in: 10..<360)
        @AppStorage ("eRandomY")var eRandomY = Int.random(in: 10..<650)
        
        @AppStorage ("cRandomX") var cRandomX = Int.random(in: 10..<361)
        @AppStorage ("cRandomY") var cRandomY = Int.random(in: 10..<651)
        
        
        func checkCollision () {
            if abs(self.xPos1 - CGFloat(eRandomX)) < 25 && abs(self.yPos1 - CGFloat(eRandomY)) < 25 {
                self.collision = true
                Active = 2
            } else {
                self.collision = false
            }
        }
        
        func checkCollisionCoin () {
            if abs(self.xPos1 - CGFloat(cRandomX)) < 25 && abs(self.yPos1 - CGFloat(cRandomY)) < 25 {
                self.collisionCoin = true
                Active = 3
            } else {
                self.collisionCoin = false
            }
        }

        
        
        
        //Character
        @State var xPos1: CGFloat = 180
        @State var yPos1: CGFloat = 360
        
        //Enemy
        @State var xPos2: CGFloat = 0
        @State var yPos2: CGFloat = 0
        
        @State var collision: Bool = false
        @State var collisionCoin: Bool = false
        
        @AppStorage ("Key To Restart") var Active = 1
        
        
        
        
        
        
        var body: some View {
            
            ZStack{
                if Active == 1 {
          
                    ActiveOne()
                    
                } else if Active == 2 {
                  
                    ActiveTwo()
                    
                } 
            }
        }
        
    }
    
    
    struct Gameplay_Previews: PreviewProvider {
        static var previews: some View {
            Gameplay()
        }
    }
