//
//  Play.swift
//  Spike
//
//  Created by Grant Willison on 10/7/20.
//

import SwiftUI

struct Play: View {
    
    @AppStorage ("Key To Restart") var Active = 1
    
    @AppStorage ("Score") var Score = 0

    
    var body: some View {
        ZStack{
            if Score <= 24 {
        Rectangle()
           .foregroundColor(Color(red: 85/255, green: 85/255, blue: 85/255))
           .edgesIgnoringSafeArea(.all)
        
            } else if Score <= 49 {
                Rectangle()
                   .foregroundColor(Color(red: 120/255, green: 120/255, blue: 120/255))
                   .edgesIgnoringSafeArea(.all)
            } else if Score <= 74 {
                Rectangle()
                   .foregroundColor(Color(red: 230/255, green: 102/255, blue: 80/255))
                   .edgesIgnoringSafeArea(.all)
            } else if Score <= 99 {
                Rectangle()
                   .foregroundColor(Color(red: 232/255, green: 222/255, blue: 52/255))
                   .edgesIgnoringSafeArea(.all)
            } else if Score <= 124 {
                Rectangle()
                   .foregroundColor(Color(red: 175/255, green: 255/255, blue: 143/255))
                   .edgesIgnoringSafeArea(.all)
            } else if Score <= 149 {
                Rectangle()
                   .foregroundColor(Color(red: 143/255, green: 255/255, blue: 209/255))
                   .edgesIgnoringSafeArea(.all)
            }  else if Score <= 179 {
                Rectangle()
                   .foregroundColor(Color(red: 143/255, green: 255/255, blue: 255/255))
                   .edgesIgnoringSafeArea(.all)
            }  else if Score <= 199 {
                Rectangle()
                   .foregroundColor(Color(red: 143/255, green: 156/255, blue: 253/255))
                   .edgesIgnoringSafeArea(.all)
            }  else if Score <= 224 {
                Rectangle()
                   .foregroundColor(Color(red: 55/255, green: 41/255, blue: 255/255))
                   .edgesIgnoringSafeArea(.all)
            } else if Score <= 249 {
                Rectangle()
                   .foregroundColor(Color(red: 126/255, green: 41/255, blue: 255/255))
                   .edgesIgnoringSafeArea(.all)
            } else if Score <= 274 {
                Rectangle()
                   .foregroundColor(Color(red: 158/255, green: 50/255, blue: 169/255))
                   .edgesIgnoringSafeArea(.all)
            } else if Score <= 299 {
                Rectangle()
                   .foregroundColor(Color(red: 181/255, green: 116/255, blue: 165/255))
                   .edgesIgnoringSafeArea(.all)
            } else if Score <= 324 {
                Rectangle()
                   .foregroundColor(Color(red: 245/255, green: 11/255, blue: 187/255))
                   .edgesIgnoringSafeArea(.all)
            } else if Score <= 349 {
                Rectangle()
                   .foregroundColor(Color(red: 245/255, green: 12/255, blue: 98/255))
                   .edgesIgnoringSafeArea(.all)
            } else if Score <= 374 {
                Rectangle()
                   .foregroundColor(Color(red: 242/255, green: 48/255, blue: 48/255))
                   .edgesIgnoringSafeArea(.all)
            } else if Score <= 399 {
                Rectangle()
                   .foregroundColor(Color(red: 227/255, green: 132/255, blue: 100/255))
                   .edgesIgnoringSafeArea(.all)
            } else if Score <= 424 {
                Rectangle()
                   .foregroundColor(Color(red: 214/255, green: 174/255, blue: 161/255))
                   .edgesIgnoringSafeArea(.all)
            }  else if Score <= 449 {
                Rectangle()
                   .foregroundColor(Color(red: 214/255, green: 198/255, blue: 193/255))
                   .edgesIgnoringSafeArea(.all)
            } else if Score <= 474 {
                Rectangle()
                   .foregroundColor(Color(red: 253/255, green: 253/255, blue: 253/255))
                   .edgesIgnoringSafeArea(.all)
            } else if Score <= 499 {
                Rectangle()
                   .foregroundColor(Color(red: 1/255, green: 1/255, blue: 1/255))
                   .edgesIgnoringSafeArea(.all)
            }
            //Portal. If Score == => 500
            
            
            BackgroundPlay()
            
            Gameplay()
            
                }
            }
        }

struct Play_Previews: PreviewProvider {
    static var previews: some View {
        Play()
    }
}
