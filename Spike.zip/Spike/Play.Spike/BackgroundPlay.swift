//
//  BackgroundPlay.swift
//  Spike
//
//  Created by Grant Willison on 10/9/20.
//

import SwiftUI

struct BackgroundPlay: View {
    
    @AppStorage ("Key To Restart") var Active = 1
    @AppStorage ("Score") var Score = 0

var body: some View {

        let randomInt = Int.random(in: 0..<1)
    
    
    if randomInt == 0 {
    HStack{
        Spacer()
        VStack{
    Image("Background.Dot")
        .scaleEffect(0.3)
            Spacer()
    Image("Background.Dot")
        .scaleEffect(0.3)
            Spacer()
    Image("Background.Dot")
        .scaleEffect(0.3)
                        }
        Spacer__()
        
        VStack{
            Spacer()
    Image("Background.Dot")
        .scaleEffect(0.3)
            Spacer__()
    Image("Background.Dot")
        .scaleEffect(0.3)
 
            Spacer__()
            Spacer__()
            Spacer__()
            
    Image("Background.Dot")
        .scaleEffect(0.3)
            Spacer()
                        }
        Spacer()
        Spacer__()
        VStack{
            Image("Background.Dot")
                .scaleEffect(0.3)
            Spacer()
        }
        VStack{
            Spacer()
    Image("Background.Dot")
        .scaleEffect(0.3)
            Spacer()
    Image("Background.Dot")
        .scaleEffect(0.3)
            Spacer__()
    Image("Background.Dot")
        .scaleEffect(0.3)
            Spacer()
                        }
        Spacer()
                    }
    } else if randomInt == 1 {
        Text("")
            }
    
}       
    }

struct BackgroundPlay_Previews: PreviewProvider {
    static var previews: some View {
        BackgroundPlay()
    }
}
