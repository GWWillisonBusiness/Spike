//
//  2Active.swift
//  Spike
//
//  Created by Grant Willison on 10/11/20.
//

import SwiftUI

struct ActiveTwo: View {
    


    
    //Scores
    @AppStorage ("HighScore") var Highscore = 0
    @AppStorage ("Score") var Score = 0
    
    @AppStorage ("eRandomX") var eRandomX = Int.random(in: 10..<360)
    @AppStorage ("eRandomY")var eRandomY = Int.random(in: 10..<650)
    
    @AppStorage ("e2RandomX") var e2RandomX = Int.random(in: 10..<360)
    @AppStorage ("e2RandomY")var e2RandomY = Int.random(in: 10..<650)
    
    @AppStorage ("e3RandomX") var e3RandomX = Int.random(in: 10..<360)
    @AppStorage ("e3RandomY")var e3RandomY = Int.random(in: 10..<650)

    
    @AppStorage ("cRandomX") var cRandomX = Int.random(in: 10..<361)
    @AppStorage ("cRandomY") var cRandomY = Int.random(in: 10..<651)

    
    
    func checkCollisionCoin () {
        if abs(self.xPos1 - CGFloat(cRandomX)) < 25 && abs(self.yPos1 - CGFloat(cRandomY)) < 25 {
            self.collisionCoin = true
            Active = 3
        } else {
            self.collisionCoin = false
        }
    }

    
    
    
    //Character
    @State var xPos1: CGFloat = 180
    @State var yPos1: CGFloat = 360
    
    //Enemy
    @State var xPos2: CGFloat = 0
    @State var yPos2: CGFloat = 0
    
    @State var collision: Bool = false
    @State var collisionCoin: Bool = false
    
    @AppStorage ("Key To Restart") var Active = 1

    
    var body: some View {
        ZStack{
            
          
            
            Spacer()
            Rectangle()
                .foregroundColor(Color.white)
                .frame(width: 300, height: 450)
                .scaledToFit()
                .cornerRadius(10)
                .padding(.all, 10)
            Spacer()
            
            VStack{
                
                Spacer__()
                Text("Game Over")
                    .bold()
                    .font(.system(size: 40))
                Spacer()
                Text("Highscore: " + String(Highscore))
                
                Text("Score: " + String(Score))
                Spacer()
                ZStack{
                    Text("Play Again")
                        .bold()
                        .foregroundColor(Color(red: 95/255, green: 250/255, blue: 77/255))
                        .padding(.all, 18)
                        .padding([.leading, .trailing], 30)
                        .background(Color.black)
                        .cornerRadius(20)
                    Button("                                        "){
                        
                        if Score > Highscore {
                            Highscore = Score
                        }
                        
                        Active = 1
                        xPos1 = 180
                        yPos1 = 360
                        
                        Score = 0
                        
                        eRandomX = Int.random(in: 10..<360)
                        eRandomY = Int.random(in: 10..<650)
                        
                        e2RandomX = Int.random(in: 10..<360)
                        e2RandomY = Int.random(in: 10..<650)
                        
                        e3RandomX = Int.random(in: 10..<360)
                        e3RandomY = Int.random(in: 10..<650)
                        
                        cRandomX = Int.random(in: 10..<360)
                        cRandomY = Int.random(in: 10..<650)
                        
                    }
                }
                
                ZStack{
                    
                    NavigationLink(destination: HomeScreen()
                                    .navigationTitle(Text(""))
                                    .navigationBarHidden(true))
                    {
                        
                        Text("HomeScreen")
                            .bold()
                            .foregroundColor(Color(red: 95/255, green: 250/255, blue: 77/255))
                            .padding(.all, 18)
                            .padding([.leading, .trailing], 30)
                            .background(Color.black)
                            .cornerRadius(20)
                        
                        
                        
                        
                    }
                }
                Spacer__()
                
            }
        }
    }
}

struct ActiveTwo_Previews: PreviewProvider {
    static var previews: some View {
        ActiveTwo()
    }
}
