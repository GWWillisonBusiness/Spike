//
//  Shapes.swift
//  Spike
//
//  Created by Grant Willison on 10/11/20.
//

import SwiftUI

struct ActiveOne: View {
    
   private var randomNumberKey = Int.random(in: 0..<10)
    
    //Green = 1, Orange = 2, Yellow = 3
    @AppStorage ("CharacterValue") var characterValue = 1
    
    //Free Currency
    @AppStorage ("Coin") private var Coin = 0
    //Paid Currency
    @AppStorage ("Ruby") private var Ruby = 0
    
    
    @AppStorage ("Coin Value") private var CoinValue = 2
 
    func changePosition () {
       
        eRandomX = Int.random(in: 10..<360)
        eRandomY = Int.random(in: 10..<650)
        
        e2RandomX = Int.random(in: 10..<360)
        e2RandomY = Int.random(in: 10..<650)
        
        e3RandomX = Int.random(in: 10..<360)
        e3RandomY = Int.random(in: 10..<650)

        cRandomX = Int.random(in: 10..<361)
        cRandomY = Int.random(in: 10..<651)

         while abs(self.xPos1 - CGFloat(eRandomX)) < 30 && abs(self.yPos1 - CGFloat(eRandomY)) < 30 {
            eRandomX = Int.random(in: 10..<360)
            eRandomY = Int.random(in: 10..<650)
        }
        while abs(self.xPos1 - CGFloat(e2RandomX)) < 30 && abs(self.yPos1 - CGFloat(e2RandomY)) < 30 {
            e2RandomX = Int.random(in: 10..<360)
            e2RandomY = Int.random(in: 10..<650)
        }

        while abs(self.xPos1 - CGFloat(e3RandomX)) < 30 && abs(self.yPos1 - CGFloat(e3RandomY)) < 30 {
            e3RandomX = Int.random(in: 10..<360)
            e3RandomY = Int.random(in: 10..<650)
        }

    }
    

    
    //Scores
    @AppStorage ("HighScore") var Highscore = 0
    @AppStorage ("Score") var Score = 0

    
    @AppStorage ("Key To Restart") var Active = 1

    @State var collision: Bool = false
    @State var collisionCoin: Bool = false
    
    func checkCollisionMoney () {
        if abs(self.xPos1 - CGFloat(coinRandomX)) < 30 && abs(self.yPos1 - CGFloat(coinRandomY)) < 30 {
            self.collisionCoin = true
            CoinValue = 2
            
            //Amount Earned Per Coin
            Coin += 1
            
        } else {
            self.collisionCoin = false
        }
    }
    
    func checkCollisionCoin () {
        if abs(self.xPos1 - CGFloat(cRandomX)) < 24 && abs(self.yPos1 - CGFloat(cRandomY)) < 24 {
            self.collisionCoin = true
            
           //Creator Mod -  changePosition()
            changePosition()
            
            Score += 1
            CoinValue = 1
        } else {
            self.collisionCoin = false
        }
    }
    
    func checkCollision () {
        if abs(self.xPos1 - CGFloat(eRandomX)) < 25 && abs(self.yPos1 - CGFloat(eRandomY)) < 25 {
            self.collision = true
            Active = 2
        } else {
            self.collision = false
        }
    }

    
    func checkCollision2 () {
        if abs(self.xPos1 - CGFloat(e2RandomX)) < 25 && abs(self.yPos1 - CGFloat(e2RandomY)) < 25 {
            self.collision = true
            Active = 2
        } else {
            self.collision = false
        }
    }
    
    func checkCollision3 () {
        if abs(self.xPos1 - CGFloat(e3RandomX)) < 25 && abs(self.yPos1 - CGFloat(e3RandomY)) < 25 {
            self.collision = true
            Active = 2
        } else {
            self.collision = false
        }
    }
    func checkCollision4 () {
        if abs(self.xPos1 - CGFloat(e4RandomX)) < 25 && abs(self.yPos1 - CGFloat(e4RandomY)) < 25 {
            self.collision = true
            Active = 2
        } else {
            self.collision = false
        }
    }


    //Location's Of Blocks
    @AppStorage ("coinRandomX") var coinRandomX = Int.random(in: 10..<360)
    @AppStorage ("coinRandomY")var coinRandomY = Int.random(in: 10..<650)
    
    @AppStorage ("eRandomX") var eRandomX = Int.random(in: 10..<360)
    @AppStorage ("eRandomY")var eRandomY = Int.random(in: 10..<650)
   
    @AppStorage ("e2RandomX") var e2RandomX = Int.random(in: 10..<360)
    @AppStorage ("e2RandomY")var e2RandomY = Int.random(in: 10..<650)
    
    @AppStorage ("e3RandomX") var e3RandomX = Int.random(in: 10..<360)
    @AppStorage ("e3RandomY")var e3RandomY = Int.random(in: 10..<650)
    
    @AppStorage ("e3RandomX") var e4RandomX = Int.random(in: 10..<360)
    @AppStorage ("e3RandomY")var e4RandomY = Int.random(in: 10..<650)
    
    @AppStorage ("cRandomX") var cRandomX = Int.random(in: 10..<361)
    @AppStorage ("cRandomY") var cRandomY = Int.random(in: 10..<651)
    
    @State var xPos1: CGFloat = 180
    @State var yPos1: CGFloat = 360
    
    //Enemy
    @State var xPos2: CGFloat = 0
    @State var yPos2: CGFloat = 0
    

    
    var body: some View {
        
        Text(String(Score))
            .bold()
            .font(.system(size: 160))
            .opacity(0.4)
        Image("SpikeEnemy")
            .resizable()
            .frame(width: 30, height: 30)
            .scaledToFit()
            .shadow(radius: 15)
            .position(x: CGFloat(eRandomX), y: self.yPos2 + CGFloat(eRandomY))
      
        if Score >= 5 {
        Image("SpikeEnemy")
            .resizable()
            .frame(width: 30, height: 30)
            .scaledToFit()
            .shadow(radius: 15)
            .position(x: CGFloat(e2RandomX), y: self.yPos2 + CGFloat(e2RandomY))
        }
        if Score >= 50 {
        Image("SpikeEnemy")
            .resizable()
            .frame(width: 30, height: 30)
            .scaledToFit()
            .shadow(radius: 15)
            .position(x: CGFloat(e3RandomX), y: self.yPos2 + CGFloat(e3RandomY))
        }
        
        if Score >= 100 {
            Image("SpikeEnemy")
                .resizable()
                .frame(width: 30, height: 30)
                .scaledToFit()
                .shadow(radius: 15)
                .position(x: CGFloat(e4RandomX), y: self.yPos2 + CGFloat(e4RandomY))

        }
        
        Image("SpikeScore")
            .resizable()
            .frame(width: 30, height: 30)
            .scaledToFit()
            .shadow(radius: 40)
            .position(x: CGFloat(cRandomX), y: CGFloat(cRandomY))
        
        if CoinValue == 1 && randomNumberKey == 1{
        Image("CoinLogo")
            .resizable()
            .frame(width: 35, height: 35)
            .scaledToFit()
            .shadow(radius: 40)
            .position(x: CGFloat(coinRandomX), y: CGFloat(coinRandomY))
        }
        if characterValue == 1{
        Image("SpikeCharacter")
            .resizable()
            .frame(width: 40, height: 40)
            .scaledToFit()
            .shadow(radius: 15)
            .position(x: self.xPos1, y: self.yPos1)
            .gesture(
                DragGesture()
                    .onChanged({ value in
                        self.xPos1 = value.location.x
                        self.yPos1 = value.location.y
                        self.checkCollisionCoin()
                        self.checkCollision()
                        if Score >= 5 {
                        self.checkCollision2()
                        }
                        if Score >= 50{
                        self.checkCollision3()
                        }
                        if Score >= 100 {
                            self.checkCollision4()
                        }
                        if CoinValue == 1 && randomNumberKey == 1{
                            self.checkCollisionMoney()
                        }
                        
                    })
            )
        } else if characterValue == 2 {
            Image("SpikeCharacterOrange")
                .resizable()
                .frame(width: 40, height: 40)
                .scaledToFit()
                .shadow(radius: 15)
                .position(x: self.xPos1, y: self.yPos1)
                .gesture(
                    DragGesture()
                        .onChanged({ value in
                            self.xPos1 = value.location.x
                            self.yPos1 = value.location.y
                            self.checkCollisionCoin()
                            self.checkCollision()
                            if Score >= 5 {
                            self.checkCollision2()
                            }
                            if Score >= 50{
                            self.checkCollision3()
                            }
                            if Score >= 100 {
                                self.checkCollision4()
                            }
                            if CoinValue == 1 && randomNumberKey == 1{
                                self.checkCollisionMoney()
                            }
                            
                        })
                )
        } else if characterValue == 3 {
            Image("SpikeCharacterYellow")
                .resizable()
                .frame(width: 40, height: 40)
                .scaledToFit()
                .shadow(radius: 15)
                .position(x: self.xPos1, y: self.yPos1)
                .gesture(
                    DragGesture()
                        .onChanged({ value in
                            self.xPos1 = value.location.x
                            self.yPos1 = value.location.y
                            self.checkCollisionCoin()
                            self.checkCollision()
                            if Score >= 5 {
                            self.checkCollision2()
                            }
                            if Score >= 50{
                            self.checkCollision3()
                            }
                            if Score >= 100 {
                                self.checkCollision4()
                            }
                            if CoinValue == 1 && randomNumberKey == 1{
                                self.checkCollisionMoney()
                            }
                            
                        })
                )
        }
    }
}

struct ActiveOne_Previews: PreviewProvider {
    static var previews: some View {
        ActiveOne()
    }
}
